/* 
 * File:   ComData.h
 * Author: Branden Hitt
 * Created on October 5, 2015, 5:17 PM
 */

#ifndef COMDATA_H
#define	COMDATA_H

struct ComData{
    //stored items
    string name;
    short qtr;
    float qtSales;
};

#endif	/* COMDATA_H */

