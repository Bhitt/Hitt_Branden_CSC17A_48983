/* 
 * File:   SpeakersBureau.h
 * Author: Administrator
 *
 * Created on October 9, 2015, 12:36 PM
 */

#ifndef SPEAKERSBUREAU_H
#define	SPEAKERSBUREAU_H

struct SpkrBru{
    string name;
    string number;
    string topic;
    float fee;
};

#endif	/* SPEAKERSBUREAU_H */

