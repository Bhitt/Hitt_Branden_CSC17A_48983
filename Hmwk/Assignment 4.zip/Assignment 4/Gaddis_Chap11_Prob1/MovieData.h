/* 
 * File:   MovieData.h
 * Author: Administrator
 *
 * Created on October 7, 2015, 8:30 PM
 */

#ifndef MOVIEDATA_H
#define	MOVIEDATA_H

struct MovieData{
    string title;
    string direct;
    unsigned short rlsYear;
    unsigned short runTime;
};

#endif	/* MOVIEDATA_H */

