var searchData=
[
  ['player',['Player',['../class_player.html',1,'']]],
  ['playerdata',['PlayerData',['../struct_player_data.html',1,'']]]
];
