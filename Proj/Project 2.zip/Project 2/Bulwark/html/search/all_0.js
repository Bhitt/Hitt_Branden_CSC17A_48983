var searchData=
[
  ['bossunit',['BossUnit',['../class_boss_unit.html',1,'']]]
];
