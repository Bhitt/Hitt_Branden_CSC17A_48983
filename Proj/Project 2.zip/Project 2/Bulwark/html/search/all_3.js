var searchData=
[
  ['greeting',['Greeting',['../struct_greeting.html',1,'']]]
];
